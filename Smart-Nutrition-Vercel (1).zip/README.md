# Smart Nutrition

A mobile-first Smart Nutrition interface with a public SEO landing page and private workspace pages.

## Vercel deployment

Import this folder into Vercel as a static project. No build command is required and the output directory is the project root. The included `vercel.json` adds secure response headers and a `/home` alias for the landing page.

The landing page is `index.html`. Private workspace pages are deliberately marked `noindex, nofollow`. `robots.txt` excludes them from crawlers.

## Browser preview mode

When deployed to Vercel, the pages use `vercel-preview.js`, a sanitized local browser adapter with demo-only records. Nothing from the supplied workbook is loaded into the public site. Demo login:

- Username: `demo`
- Password: `demo123`

Data entered in preview mode is stored only in the current browser's local storage.

## Google Apps Script backend

The original Apps Script backend is preserved in `apps-script/Sdmp.js`. It is excluded from Vercel by `.vercelignore`. Deploy it separately as a Google Apps Script web app if production spreadsheet-backed operations are required, then replace the preview adapter with an authenticated API integration rather than exposing spreadsheet credentials in frontend code.

The supplied workbook is preserved in `source-data/SDM.xlsx` and is excluded from Vercel deployment. Review and remove sensitive records before sharing it.
