(function () {
  'use strict';
  var pages = {
    Login: 'login.html',
    AdminDashboard: 'adminDashboard.html',
    UserDashboard: 'PersonalDetails.html',
    PersonalDetails: 'PersonalDetails.html',
    DietTwin: 'DietTwin.html',
    DietPlan: 'DietPlan.html',
    WeightTracking: 'WeightTracking.html',
    Reports: 'Reports.html',
    HelpSupport: 'HelpSupport.html'
  };
  function go(page) {
    window.location.href = pages[page] || pages.Login;
  }
  window.openPage = go;
  window.navigateToPage = function (_, page) { go(page); };
  window.navigateToAppPage = go;
  window.goToAdmin = function () { go('AdminDashboard'); };
  window.goToDietPlan = function () { go('DietPlan'); };
  window.goToWeightTracking = function () { go('WeightTracking'); };
  window.logout = function () { go('Login'); };
  window.SDM_PAGE_MAP = pages;
})();
