(function () {
  'use strict';

  var STORAGE_KEY = 'sdm-vercel-demo-v1';
  var seed = {
    users: [
      {
        id: 'DEMO-001', name: 'Demo Member', mobile: '', nationalid: '', email: 'demo@example.com',
        age: 30, gender: 'Female', heightcm: 165, currentweightkg: 68, dietprefernce: 'Vegetarian',
        country: 'India', healthconditions: '', targetweightkg: 62, foodallergies: '', medicalconditions: '',
        sleephours: 7, waterintakel: 2.2, exerciseminutes: 30
      },
      {
        id: 'DEMO-002', name: 'Sample Member', mobile: '', nationalid: '', email: 'sample@example.com',
        age: 35, gender: 'Male', heightcm: 178, currentweightkg: 82, dietprefernce: 'Balanced',
        country: 'India', healthconditions: '', targetweightkg: 76, foodallergies: '', medicalconditions: '',
        sleephours: 7.5, waterintakel: 2.5, exerciseminutes: 40
      }
    ],
    weights: [],
    requests: []
  };

  function readState() {
    try {
      var saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || 'null');
      if (saved && saved.users && saved.weights && saved.requests) return saved;
    } catch (_) {}
    return JSON.parse(JSON.stringify(seed));
  }

  function writeState(state) {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (_) {}
  }

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function bmi(height, weight) {
    var h = Number(height) / 100;
    var w = Number(weight);
    return h > 0 && w > 0 ? Math.round((w / (h * h)) * 10) / 10 : 0;
  }

  function profileFor(user) {
    var p = clone(user);
    p.height = p.heightcm;
    p.weight = p.currentweightkg;
    p.currentWeight = p.currentweightkg;
    p.targetWeight = p.targetweightkg;
    p.bmi = bmi(p.heightcm, p.currentweightkg);
    p.targetBmi = bmi(p.heightcm, p.targetweightkg);
    p.weightDifference = Number(p.currentweightkg || 0) - Number(p.targetweightkg || 0);
    p.dietPreference = p.dietprefernce;
    p.healthConditions = p.healthconditions;
    p.medicalConditions = p.medicalconditions;
    p.foodAllergies = p.foodallergies;
    p.sleepHours = p.sleephours;
    p.waterIntake = p.waterintakel;
    p.exerciseMinutes = p.exerciseminutes;
    return p;
  }

  function findUser(state, idOrName) {
    var wanted = String(idOrName || '').trim().toLowerCase();
    return state.users.find(function (u) {
      return String(u.id).toLowerCase() === wanted || String(u.name).toLowerCase() === wanted;
    });
  }

  function recordsFor(state, userId) {
    return state.weights.filter(function (r) { return r.userId === userId; })
      .sort(function (a, b) { return String(b.recordDate).localeCompare(String(a.recordDate)); });
  }

  function rowsForPersonalDetails(state, search) {
    var q = String(search || '').trim().toLowerCase();
    return state.users.filter(function (u) {
      return !q || [u.id, u.name, u.email, u.country].join(' ').toLowerCase().indexOf(q) !== -1;
    }).map(function (u) { return clone(u); }).reverse();
  }

  function reportData(state, fullName, reportType, filters) {
    var user = findUser(state, fullName);
    if (!user) return { headers: [], rows: [], total: 0, reportType: reportType, fullName: fullName };
    filters = filters || {};
    if (reportType === 'Weight History') {
      var wr = recordsFor(state, user.id).filter(function (r) {
        return (!filters.fromDate || r.recordDate >= filters.fromDate) && (!filters.toDate || r.recordDate <= filters.toDate);
      });
      return { headers: ['Fullname', 'RecordID', 'UserID', 'RecordDate', 'Weight_kg', 'Waist_cm', 'Notes'], rows: wr.map(function (r) { return [user.name, r.recordId, r.userId, r.recordDate, r.weightKg, r.waistCm, r.notes]; }), total: wr.length, reportType: reportType, fullName: user.name };
    }
    return { headers: ['FullName', 'Country', 'Diet Preference', 'Current Weight (kg)', 'Target Weight (kg)', 'BMI'], rows: [[user.name, user.country, user.dietprefernce, user.currentweightkg, user.targetweightkg, bmi(user.heightcm, user.currentweightkg)]], total: 1, reportType: reportType, fullName: user.name };
  }

  function mock(method, args) {
    var state = readState();
    var arg = args && args[0];
    switch (method) {
      case 'login':
        if ((String(arg || '').trim() === 'demo' && String(args[1] || '') === 'demo123') || (String(arg || '').trim() === 'admin' && String(args[1] || '') === 'admin123')) {
          return { ok: true, username: arg, role: String(arg).toLowerCase() === 'admin' ? 'admin' : 'user', url: window.location.origin + (String(arg).toLowerCase() === 'admin' ? '/adminDashboard.html' : '/PersonalDetails.html'), message: 'Demo login successful.' };
        }
        return { ok: false, message: 'Use demo / demo123 for the Vercel preview.' };
      case 'getWebAppUrl': case 'getDietTwinWebAppUrl': return window.location.origin + '/';
      case 'getDigitalTwinUsers': case 'getDietPlanUsers': case 'getWeightTrackingUsers':
        return { ok: true, users: state.users.map(function (u) { return { id: u.id, name: u.name, gender: u.gender }; }), message: state.users.length + ' demo profiles loaded.' };
      case 'getDigitalTwinData':
        var dt = findUser(state, arg); return dt ? { ok: true, profile: profileFor(dt), message: 'Demo profile loaded.' } : { ok: false, message: 'Profile not found.' };
      case 'getDietPlanProfile':
        var dp = findUser(state, arg); return dp ? Object.assign(profileFor(dp), { ok: true }) : { ok: false, message: 'Profile not found.' };
      case 'listPersonalDetails': return rowsForPersonalDetails(state, arg);
      case 'savePersonalDetails':
        var data = clone(arg || {}); data.id = data.UserID || ('DEMO-' + Date.now()); data.name = data.FullName || data.fullName || 'New member'; data.fullname = data.name; data.heightcm = data.heightcm || data.Height_cm || ''; data.currentweightkg = data.currentweightkg || data.CurrentWeight_kg || ''; data.targetweightkg = data.targetweightkg || data.TargetWeight_kg || ''; data.dietprefernce = data.dietprefernce || data['Diet Prefernce'] || ''; data.country = data.country || data.Country || ''; state.users.push(data); writeState(state); return { ok: true, userId: data.id, message: 'Profile saved in this browser demo.' };
      case 'updatePersonalDetailsRecord':
        var existing = findUser(state, arg); if (!existing) return { ok: false, message: 'Profile not found.' }; Object.assign(existing, clone(args[1] || {})); writeState(state); return { ok: true, userId: existing.id, message: 'Profile updated in this browser demo.' };
      case 'initializeWeightTrackingSheet': return { ok: true, sheetName: 'WeightTracking (browser demo)' };
      case 'getWeightTrackingRecords': return recordsFor(state, String(arg || ''));
      case 'saveWeightTrackingRecord':
        var rec = clone(arg || {}); rec.recordId = rec.recordId || ('DEMO-REC-' + Date.now()); rec.weightKg = Number(rec.weightKg); rec.waistCm = rec.waistCm === '' ? '' : Number(rec.waistCm); var idx = state.weights.findIndex(function (r) { return r.recordId === rec.recordId; }); if (idx >= 0) state.weights[idx] = rec; else state.weights.push(rec); writeState(state); return { ok: true, recordId: rec.recordId, message: idx >= 0 ? 'Measurement updated in this browser demo.' : 'Measurement saved in this browser demo.' };
      case 'getInitialData': return { fullNames: state.users.map(function (u) { return u.name; }), reportTypes: ['Personal Details', 'Diet Plan', 'Weight History'] };
      case 'getReportData': return reportData(state, args[0], args[1], args[2]);
      case 'getHelpSupportRequests': return clone(state.requests);
      case 'submitHelpSupportRequest':
        var ticket = 'DEMO-' + Date.now(); state.requests.unshift({ ticketId: ticket, status: 'Open', category: (arg || {}).category || 'General Enquiry', priority: (arg || {}).priority || 'Normal', createdAt: new Date().toLocaleString() }); writeState(state); return { ok: true, success: true, ticketId: ticket, message: 'Request saved in this browser demo.' };
      case 'getHelpSupportAdminRequests': return clone(state.requests);
      default: return { ok: true, message: 'Demo mode: ' + property };
    }
  }

  function runner() {
    var success = function () {};
    var failure = function () {};
    var proxy;
    var api = { withSuccessHandler: function (fn) { success = fn || success; return proxy; }, withFailureHandler: function (fn) { failure = fn || failure; return proxy; } };
    proxy = new Proxy(api, { get: function (target, property) { if (property in target) return target[property]; return function () { var args = Array.prototype.slice.call(arguments); window.setTimeout(function () { try { var result = mock(property, args); success(result); } catch (error) { failure(error); } finally { success = function () {}; failure = function () {}; } }, 0); }; } });
    return proxy;
  }

  window.google = window.google || {};
  window.google.script = window.google.script || {};
  window.google.script.run = runner();
  window.SDM_VERCEL_PREVIEW = true;
})();
